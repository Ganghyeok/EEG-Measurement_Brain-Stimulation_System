/*
 * main.h
 *
 *  Created on: Mar 7, 2021
 *      Author: Ganghyeok Lim
 */

#ifndef MAIN_H_
#define MAIN_H_

#include "stm32f407xx.h"
#include "common.h"
#include "DSP.h"


/*================ User configurable parameters =================*/

#define N			256		// Length of Block (must be a power of two)
#define MF			4		// Length of FIR filter
#define L			253		// Length of Input data to be processed at a time => L should be (N-MF+1)

//=================================================================


void LED1_Init(void);

extern uint32_t SystemCoreClock;
extern const uint8_t AHBPrescTable[16];
extern const uint8_t APBPrescTable[8];


extern uint32_t AdcSample;
extern uint32_t DacOutputBuffer[L];

/* ====================== DSP variables ========================= */
extern uint8_t			InFullFlag;
extern double			InputBuffer[L];
extern double			OutputBuffer[L];
extern uint8_t			OutFullFlag;

//=================================================================





/* ------------------------------- Application Specific ------------------------------- */

/* Application Specific Macro */


/* Application Specific Macro functions */


/* Application Specific C functions */
extern void DMA1_Init(void);
extern void DMA2_Init(void);
extern void LED1_Init(void);
extern void TIM6_Init(void);
extern void TIM7_Init(void);
extern void UART1_Init(void);
extern void ADC1_Init(void);
extern void DAC1_Init(void);
extern void MemsetHandleStructure(void);

/* Peripheral Handle Definitions */
extern TIM_HandleTypeDef		TIM6Handle;
extern TIM_HandleTypeDef		TIM7Handle;
extern UART_HandleTypeDef		USART1Handle;
extern DMA_HandleTypeDef		DMA2Handle_UART;
extern ADC_HandleTypeDef		ADC1Handle;
extern DMA_HandleTypeDef		DMA2Handle_ADC;
extern DAC_HandleTypeDef		DAC1Handle;
extern DMA_HandleTypeDef		DMA1Handle_DAC;

/* Status Flags */


/* Peripheral Initialization functions */


/* Peripheral Callback functions */






#endif /* MAIN_H_ */
