/*
 * user_func.c
 *
 *  Created on: Mar 7, 2021
 *      Author: Ganghyeok Lim
 */

#include "main.h"


TIM_HandleTypeDef		TIM6Handle;
TIM_HandleTypeDef		TIM7Handle;
UART_HandleTypeDef		USART1Handle;
DMA_HandleTypeDef		DMA2Handle_UART;
ADC_HandleTypeDef		ADC1Handle;
DMA_HandleTypeDef		DMA2Handle_ADC;
DAC_HandleTypeDef		DAC1Handle;
DMA_HandleTypeDef		DMA1Handle_DAC;


uint32_t SystemCoreClock = 168000000;
const uint8_t AHBPrescTable[16] = {0, 0, 0, 0, 0, 0, 0, 0, 1, 2, 3, 4, 6, 7, 8, 9};
const uint8_t APBPrescTable[8]  = {0, 0, 0, 0, 1, 2, 3, 4};



uint32_t AdcSample = 0;
uint32_t DacOutputBuffer[L] = {0,};

/************* Test *************/
extern uint32_t sine_val[100];

/********************************/


/********************************************************************************************************************
 * 																											  		*
 *											Application Specific Function											*
 * 																											  		*
 ********************************************************************************************************************/

/********************************************** Initialization Function *********************************************/

void LED1_Init(void)
{
	GPIO_InitTypeDef GPIO_LED;

	memset(&GPIO_LED, 0, sizeof(GPIO_LED));

	GPIO_LED.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_LED.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
	GPIO_LED.Pin = GPIO_PIN_1;

	GPIO_Init(GPIOA, &GPIO_LED);
}

void MemsetHandleStructure(void)
{
	memset(&TIM6Handle, 0, sizeof(TIM6Handle));
	memset(&TIM7Handle, 0, sizeof(TIM7Handle));
	memset(&USART1Handle, 0, sizeof(USART1Handle));
	memset(&DMA2Handle_UART, 0, sizeof(DMA2Handle_UART));
	memset(&ADC1Handle, 0, sizeof(ADC1Handle));
	memset(&DMA2Handle_ADC, 0, sizeof(DMA2Handle_ADC));
	memset(&DAC1Handle, 0, sizeof(DAC1Handle));
	memset(&DMA1Handle_DAC, 0, sizeof(DMA1Handle_DAC));
}

/************************************************* Normal Function *************************************************/








/********************************************************************************************************************
 * 																											  		*
 *											 Peripheral Specific Function											*
 * 																											  		*
 ********************************************************************************************************************/

/********************************************** Initialization Function *********************************************/

void TIM6_Init(void)
{
	// Init TIM6 Base
	TIM6Handle.Instance = TIM6;
	TIM6Handle.Init.CounterMode = TIM_COUNTERMODE_UP;
	TIM6Handle.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
	TIM6Handle.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_ENABLE;
	TIM6Handle.Init.Prescaler = (84-1);	// 84MHz / 84 = 1MHz
	TIM6Handle.Init.Period = (10-1);	// 1MHz / 10 = 100kHz
	TIM_Base_Init(&TIM6Handle);
}


void TIM7_Init(void)
{
	TIM_MasterConfigTypeDef sMasterConfig = {0};

	TIM7Handle.Instance = TIM7;
	TIM7Handle.Init.Prescaler = 84-1;
	TIM7Handle.Init.CounterMode = TIM_COUNTERMODE_UP;
	TIM7Handle.Init.Period = 10-1;
	TIM7Handle.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
	TIM_Base_Init(&TIM7Handle);

	sMasterConfig.MasterOutputTrigger = TIM_TRGO_UPDATE;
	sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
	TIMEx_MasterConfigSynchronization(&TIM7Handle, &sMasterConfig);
}


void UART1_Init(void)
{
	USART1Handle.Instance = USART1;
	USART1Handle.Init.Mode = UART_MODE_TX;
	USART1Handle.Init.OverSampling = UART_OVERSAMPLING_16;
	USART1Handle.Init.BaudRate = USART_STD_BAUD_115200;
	USART1Handle.Init.Parity = UART_PARITY_NONE;
	USART1Handle.Init.StopBits = UART_STOPBITS_1;
	USART1Handle.Init.HwFlowCtl = UART_HWCONTROL_NONE;
	USART1Handle.Init.WordLength = UART_WORDLENGTH_8B;

	UART_Init(&USART1Handle);
}


void DMA1_Init(void)
{
	// 1. DMA1 Clock Enable
	RCC_DMA1_CLK_ENABLE();

	// 2. Configure NVIC Setting of DMA1_Stream5
	NVIC_IRQConfig(DMA1_Stream5_IRQn, 2, ENABLE);
}


void DMA2_Init(void)
{
	// 1. DMA2 Clock Enable
	RCC_DMA2_CLK_ENABLE();

	// 2. Configure NVIC Setting of DMA2_Stream7
	NVIC_IRQConfig(DMA2_Stream7_IRQn, 2, ENABLE);

	// 3. Configure NVIC Setting of DMA2_Stream4
	NVIC_IRQConfig(DMA2_Stream4_IRQn, 2, ENABLE);
}


void ADC1_Init(void)
{
	ADC_ChannelConfTypeDef sConfig = {0};

	// 1. Configure the global features of the ADC (Clock, Resolution, Data Alignment and number of conversion)
	ADC1Handle.Instance = ADC1;
	ADC1Handle.Init.ClockPrescaler = ADC_CLOCK_SYNC_PCLK_DIV4;
	ADC1Handle.Init.Resolution = ADC_RESOLUTION_12B;
	ADC1Handle.Init.ScanConvMode = DISABLE;
	ADC1Handle.Init.ContinuousConvMode = DISABLE;
	ADC1Handle.Init.DiscontinuousConvMode = DISABLE;
	ADC1Handle.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_NONE;
	ADC1Handle.Init.ExternalTrigConv = ADC_SOFTWARE_START;
	ADC1Handle.Init.DataAlign = ADC_DATAALIGN_RIGHT;
	ADC1Handle.Init.NbrOfConversion = 1;
	ADC1Handle.Init.DMAContinuousRequests = ENABLE;
	ADC1Handle.Init.EOCSelection = ADC_EOC_SINGLE_CONV;
	ADC_Init(&ADC1Handle);

	// 2. Configure for the selected ADC regular channel its corresponding rank in the sequencer and its sample time.
	sConfig.Channel = ADC_CHANNEL_0;
	sConfig.Rank = 1;
	sConfig.SamplingTime = ADC_SAMPLETIME_3CYCLES;
	ADC_ConfigChannel(&ADC1Handle, &sConfig);
}


void DAC1_Init(void)
{
	DAC_ChannelConfTypeDef sConfig = {0};


	DAC1Handle.Instance = DAC;
	DAC_Init(&DAC1Handle);

	sConfig.DAC_Trigger = DAC_TRIGGER_T7_TRGO;
	sConfig.DAC_OutputBuffer = DAC_OUTPUTBUFFER_ENABLE;
	DAC_ConfigChannel(&DAC1Handle, &sConfig, DAC_CHANNEL_1);
}

/************************************************* Normal Function **************************************************/





/************************************************* Callback Function ************************************************/

void TIM_PeriodElapsedCallback(TIM_HandleTypeDef *pTIMHandle)
{
	if(pTIMHandle->Instance == TIM6)
	{
		/* Timer Period is 10us */

		// TFlag is related to Delay functions
		TFlag = FLAG_SET;

		// A/D Conversion is executed every 10us, result of ADC is stored in 'AdcSample' variable
		ADC_Start_DMA(&ADC1Handle, &AdcSample, 1);




	}
}


void USART_ApplicationEventCallback(UART_HandleTypeDef *pUSARTHandle, uint8_t AppEV)
{
	if(pUSARTHandle->Instance == USART1)
	{
		if(AppEV == USART_EVENT_TX_CMPLT)
		{
			asm("NOP");
		}
	}
}


void ADC_ConvCpltCallback(ADC_HandleTypeDef* pADCHandle)
{
//	if(pADCHandle->Instance == ADC1)
//	{
//		static int cnt = 0;
//
//		DacOutputBuffer[cnt] = AdcSample;
//
//		cnt++;
//
//		if(cnt >= 100)
//		{
//			cnt = 0;
//		}
//	}

	// New
	static int cnt = 0;

	DacOutputBuffer[cnt] = (uint16_t)((OutputBuffer[cnt]+1)*2047);

	cnt++;

	if(cnt >= L)
	{
		cnt = 0;
	}
}


void DAC_ConvCpltCallbackCh1(DAC_HandleTypeDef* pDACHandle)
{
	if(pDACHandle->Instance == DAC1)
	{
//		asm("NOP");
	}

}









