/*
 * user_func.c
 *
 *  Created on: Mar 7, 2021
 *      Author: Ganghyeok Lim
 */

#include "main.h"


TIM_HandleTypeDef		TIM6Handle;
TIM_HandleTypeDef		TIM7Handle;
UART_HandleTypeDef		USART1Handle;
DMA_HandleTypeDef		DMA2Handle_UART;
ADC_HandleTypeDef		ADC1Handle;
DMA_HandleTypeDef		DMA2Handle_ADC;
DAC_HandleTypeDef		DAC1Handle;
DMA_HandleTypeDef		DMA1Handle_DAC;
TFT_HandleTypeDef		TFT1Handle;

uint32_t SystemCoreClock = 168000000;
const uint8_t AHBPrescTable[16] = {0, 0, 0, 0, 0, 0, 0, 0, 1, 2, 3, 4, 6, 7, 8, 9};
const uint8_t APBPrescTable[8]  = {0, 0, 0, 0, 1, 2, 3, 4};



uint32_t AdcSample = 0;
uint32_t DacOutputBuffer[L] = {0,};

uint8_t State = STATE_INTRO;

/************* Test *************/
extern uint32_t sine_val[100];

/********************************/


/********************************************************************************************************************
 * 																											  		*
 *											Application Specific Function											*
 * 																											  		*
 ********************************************************************************************************************/

/********************************************** Initialization Function *********************************************/

void LED1_Init(void)
{
	GPIO_InitTypeDef GPIO_LED;

	memset(&GPIO_LED, 0, sizeof(GPIO_LED));

	GPIO_LED.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_LED.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
	GPIO_LED.Pin = GPIO_PIN_1;

	GPIO_Init(GPIOA, &GPIO_LED);
}

void MemsetHandleStructure(void)
{
	memset(&TIM6Handle, 0, sizeof(TIM6Handle));
	memset(&TIM7Handle, 0, sizeof(TIM7Handle));
	memset(&USART1Handle, 0, sizeof(USART1Handle));
	memset(&DMA2Handle_UART, 0, sizeof(DMA2Handle_UART));
	memset(&ADC1Handle, 0, sizeof(ADC1Handle));
	memset(&DMA2Handle_ADC, 0, sizeof(DMA2Handle_ADC));
	memset(&DAC1Handle, 0, sizeof(DAC1Handle));
	memset(&DMA1Handle_DAC, 0, sizeof(DMA1Handle_DAC));
	memset(&TFT1Handle, 0, sizeof(TFT1Handle));
}


void GATE_DRIVER_Init(void)
{
	GPIO_InitTypeDef GPIO_GD;

	memset(&GPIO_GD, 0, sizeof(GPIO_GD));

	GPIO_GD.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_GD.Speed = GPIO_SPEED_FREQ_VERY_HIGH;

	GPIO_GD.Pin = GPIO_PIN_2;
	GPIO_Init(GPIOA, &GPIO_GD);

	GPIO_GD.Pin = GPIO_PIN_3;
	GPIO_Init(GPIOA, &GPIO_GD);

	GPIO_GD.Pin = GPIO_PIN_4;
	GPIO_Init(GPIOA, &GPIO_GD);

	GPIO_GD.Pin = GPIO_PIN_5;
	GPIO_Init(GPIOA, &GPIO_GD);
}


/************************************************* Normal Function *************************************************/

void State_Intro(void)
{
	TFT_Rectangle(&TFT1Handle, 0, 0, 319, 239, Blue);
	TFT_Rectangle(&TFT1Handle, 1, 1, 318, 238, Blue);
	TFT_String_Large(&TFT1Handle, 3, 6, White, Magenta, (uint8_t*)" EEG Measurement &  ");
	TFT_String_Large(&TFT1Handle, 3, 10, White, Magenta, (uint8_t*)" Stimulation System ");
	TFT_String(&TFT1Handle, 6, 20, White, Magenta, (uint8_t*)" Designed by Ganghyeok Lim ");
	while(1);
}


void State_Time_Domain(void)
{
	TFT_String(&TFT1Handle, 14, 0, White, Blue, (uint8_t *)" Time-Domain ");


	/* X-axis */

	// 1. Draw x-axis
	TFT_Line(&TFT1Handle, 50, 216, 310, 216, White);	// straight line of x-axis
	TFT_Line(&TFT1Handle, 305, 211, 310, 216, White);	// upper arrow head of x-axis
	TFT_Line(&TFT1Handle, 305, 221, 310, 216, White);	// lower arrow head of x-axis
	TFT_Line(&TFT1Handle, 100, 216, 100, 220, White); 	// gradation for 5[s]
	TFT_Line(&TFT1Handle, 150, 216, 150, 220, White); 	// gradation for 10[s]
	TFT_Line(&TFT1Handle, 200, 216, 200, 220, White); 	// gradation for 15[s]
	TFT_Line(&TFT1Handle, 250, 216, 250, 220, White); 	// gradation for 20[s]
	TFT_Line(&TFT1Handle, 300, 216, 300, 220, White); 	// gradation for 25[s]


	// 2. Draw dotted lines for x-axis
	for(int i = 100; i <= 300; i = i + 50)
	{
		for(int j = 20; j <= 215; j = j + 5)
		{
			TFT_Pixel(&TFT1Handle, i, j, White);
		}
	}


	// 3. Print Time label[s] corresponding to the x-axis gradation
	TFT_Color(&TFT1Handle, Cyan, Black);
	TFT_English_pixel(&TFT1Handle, 45, 222, '0');		// time label of 0[s]

	TFT_English_pixel(&TFT1Handle, 89, 222, '0');		// time label of 0.5[s]
	TFT_English_pixel(&TFT1Handle, 97, 222, '.');
	TFT_English_pixel(&TFT1Handle, 106, 222, '5');

	TFT_English_pixel(&TFT1Handle, 139, 222, '1');		// time label of 1.0[s]
	TFT_English_pixel(&TFT1Handle, 147, 222, '.');
	TFT_English_pixel(&TFT1Handle, 155, 222, '0');

	TFT_English_pixel(&TFT1Handle, 189, 222, '1');		// time label of 1.5[s]
	TFT_English_pixel(&TFT1Handle, 197, 222, '.');
	TFT_English_pixel(&TFT1Handle, 205, 222, '5');

	TFT_English_pixel(&TFT1Handle, 239, 222, '2');		// time label of 2.0[s]
	TFT_English_pixel(&TFT1Handle, 247, 222, '.');
	TFT_English_pixel(&TFT1Handle, 255, 222, '0');

	TFT_English_pixel(&TFT1Handle, 289, 222, '2');		// time label of 2.5[s]
	TFT_English_pixel(&TFT1Handle, 297, 222, '.');
	TFT_English_pixel(&TFT1Handle, 305, 222, '5');


	// 4. Print Time unit[s] to x-axis
	TFT_Color(&TFT1Handle, Magenta, Black);
	TFT_English_pixel(&TFT1Handle, 288, 222, '[');		// time unit[s]
	TFT_English_pixel(&TFT1Handle, 296, 222, 's');
	TFT_English_pixel(&TFT1Handle, 304, 222, ']');



	/* Y-axis */

	// 1. Draw y-axis
	TFT_Line(&TFT1Handle, 49, 215, 49, 5, White);		// straight line of y-axis
	TFT_Line(&TFT1Handle, 44, 10, 49, 5, White);		// left arrow head of y-axis
	TFT_Line(&TFT1Handle, 54, 10, 49, 5, White);		// right arrow head of y-axis
	TFT_Line(&TFT1Handle, 45, 23, 49, 23, White);		// gradation for +3.3[V]
	TFT_Line(&TFT1Handle, 45, 55, 49, 55, White);		// gradation for +2.75[V]
	TFT_Line(&TFT1Handle, 45, 87, 49, 87, White);		// gradation for +2.2[V]
	TFT_Line(&TFT1Handle, 45, 119, 49, 119, White);		// gradation for +1.65[V]
	TFT_Line(&TFT1Handle, 45, 151, 49, 151, White);		// gradation for +1.1[V]
	TFT_Line(&TFT1Handle, 45, 183, 49, 183, White);		// gradation for +0.55[V]


	// 2. Draw dotted lines for y-axis
	for(int j = 23; j <= 183; j = j + 32)
	{
		for(int i = 50; i <= 310; i = i + 5)
		{
			TFT_Pixel(&TFT1Handle, i, j, White);
		}
	}

	// 3. Print Speed label[rpm] corresponding to the y-axis gradation
	TFT_Color(&TFT1Handle, Cyan, Black);
	TFT_English_pixel(&TFT1Handle, 0, 16, '+');			// Voltage label of +3.3[V]
	TFT_English_pixel(&TFT1Handle, 8, 16, '3');
	TFT_English_pixel(&TFT1Handle, 16, 16, '.');
	TFT_English_pixel(&TFT1Handle, 24, 16, '3');
	TFT_English_pixel(&TFT1Handle, 32, 16, '0');

	TFT_English_pixel(&TFT1Handle, 0, 48, '+');			// Voltage label of +2.75[V]
	TFT_English_pixel(&TFT1Handle, 8, 48, '2');
	TFT_English_pixel(&TFT1Handle, 16, 48, '.');
	TFT_English_pixel(&TFT1Handle, 24, 48, '7');
	TFT_English_pixel(&TFT1Handle, 32, 48, '5');

	TFT_English_pixel(&TFT1Handle, 0, 80, '+');			// Voltage label of +2.2[V]
	TFT_English_pixel(&TFT1Handle, 8, 80, '2');
	TFT_English_pixel(&TFT1Handle, 16, 80, '.');
	TFT_English_pixel(&TFT1Handle, 24, 80, '2');
	TFT_English_pixel(&TFT1Handle, 32, 80, '0');

	TFT_English_pixel(&TFT1Handle, 0, 112, '+');		// Voltage label of +1.65[V]
	TFT_English_pixel(&TFT1Handle, 8, 112, '1');
	TFT_English_pixel(&TFT1Handle, 16, 112, '.');
	TFT_English_pixel(&TFT1Handle, 24, 112, '6');
	TFT_English_pixel(&TFT1Handle, 32, 112, '5');

	TFT_English_pixel(&TFT1Handle, 0, 144, '+');		// Voltage label of +1.1[V]
	TFT_English_pixel(&TFT1Handle, 8, 144, '1');
	TFT_English_pixel(&TFT1Handle, 16, 144, '.');
	TFT_English_pixel(&TFT1Handle, 24, 144, '1');
	TFT_English_pixel(&TFT1Handle, 32, 144, '0');

	TFT_English_pixel(&TFT1Handle, 0, 176, '+');		// Voltage label of +0.55[V]
	TFT_English_pixel(&TFT1Handle, 8, 176, '0');
	TFT_English_pixel(&TFT1Handle, 16, 176, '.');
	TFT_English_pixel(&TFT1Handle, 24, 176, '5');
	TFT_English_pixel(&TFT1Handle, 32, 176, '5');

	TFT_English_pixel(&TFT1Handle, 0, 208, '+');		// Voltage label of +0[V]
	TFT_English_pixel(&TFT1Handle, 8, 208, '0');
	TFT_English_pixel(&TFT1Handle, 16, 208, '.');
	TFT_English_pixel(&TFT1Handle, 24, 208, '0');
	TFT_English_pixel(&TFT1Handle, 32, 208, '0');

	// 4. Print Speed unit[rpm] to y-axis
	TFT_Color(&TFT1Handle, Magenta, Black);
	TFT_English_pixel(&TFT1Handle, 10, 0, '[');
	TFT_English_pixel(&TFT1Handle, 18, 0, 'V');
	TFT_English_pixel(&TFT1Handle, 26, 0, ']');


	/* Graph test */
	uint32_t sine_val[250];

	for(int i=0; i<250; i++)
	{
		sine_val[i] = ((sin(i*2*pi/200) + 1) * (4095 / 2));
	}


	uint16_t y_val;


	while(1)
	{
		for(int x = 51; x <= 300; x++)
		{
			y_val = (-1)*64./1365.*sine_val[x-51] + 215;
			TFT_Pixel(&TFT1Handle, x, y_val, Green);
		}
		Delay_ms(2000);

		Clear_Graph(&TFT1Handle);
		Delay_ms(2000);
	}
}


void State_Freq_Domain(void)
{

	while(1);
}






/********************************************************************************************************************
 * 																											  		*
 *											 Peripheral Specific Function											*
 * 																											  		*
 ********************************************************************************************************************/

/********************************************** Initialization Function *********************************************/

void TIM6_Init(void)
{
	// Init TIM6 Base
	TIM6Handle.Instance = TIM6;
	TIM6Handle.Init.CounterMode = TIM_COUNTERMODE_UP;
	TIM6Handle.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
	TIM6Handle.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_ENABLE;
	TIM6Handle.Init.Prescaler = (84-1);	// 84MHz / 84 = 1MHz
	TIM6Handle.Init.Period = (10-1);	//  1khz             origin : 1MHz / 10 = 100kHz
	TIM_Base_Init(&TIM6Handle);
}


void TIM7_Init(void)
{
	TIM_MasterConfigTypeDef sMasterConfig = {0};

	// origin : Prescaler = 84-1, Period = 10-1

	TIM7Handle.Instance = TIM7;
	TIM7Handle.Init.Prescaler = 84-1;
	TIM7Handle.Init.CounterMode = TIM_COUNTERMODE_UP;
	TIM7Handle.Init.Period = 10-1;
	TIM7Handle.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
	TIM_Base_Init(&TIM7Handle);

	sMasterConfig.MasterOutputTrigger = TIM_TRGO_UPDATE;
	sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
	TIMEx_MasterConfigSynchronization(&TIM7Handle, &sMasterConfig);
}


void UART1_Init(void)
{
	USART1Handle.Instance = USART1;
	USART1Handle.Init.Mode = UART_MODE_TX;
	USART1Handle.Init.OverSampling = UART_OVERSAMPLING_16;
	USART1Handle.Init.BaudRate = USART_STD_BAUD_115200;
	USART1Handle.Init.Parity = UART_PARITY_NONE;
	USART1Handle.Init.StopBits = UART_STOPBITS_1;
	USART1Handle.Init.HwFlowCtl = UART_HWCONTROL_NONE;
	USART1Handle.Init.WordLength = UART_WORDLENGTH_8B;

	UART_Init(&USART1Handle);
}


void DMA1_Init(void)
{
	// 1. DMA1 Clock Enable
	RCC_DMA1_CLK_ENABLE();

	// 2. Configure NVIC Setting of DMA1_Stream5
	NVIC_IRQConfig(DMA1_Stream5_IRQn, 2, ENABLE);
}


void DMA2_Init(void)
{
	// 1. DMA2 Clock Enable
	RCC_DMA2_CLK_ENABLE();

	// 2. Configure NVIC Setting of DMA2_Stream7
	NVIC_IRQConfig(DMA2_Stream7_IRQn, 2, ENABLE);

	// 3. Configure NVIC Setting of DMA2_Stream4
	NVIC_IRQConfig(DMA2_Stream4_IRQn, 2, ENABLE);
}


void ADC1_Init(void)
{
	ADC_ChannelConfTypeDef sConfig = {0};

	// 1. Configure the global features of the ADC (Clock, Resolution, Data Alignment and number of conversion)
	ADC1Handle.Instance = ADC1;
	ADC1Handle.Init.ClockPrescaler = ADC_CLOCK_SYNC_PCLK_DIV4;
	ADC1Handle.Init.Resolution = ADC_RESOLUTION_12B;
	ADC1Handle.Init.ScanConvMode = DISABLE;
	ADC1Handle.Init.ContinuousConvMode = DISABLE;
	ADC1Handle.Init.DiscontinuousConvMode = DISABLE;
	ADC1Handle.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_NONE;
	ADC1Handle.Init.ExternalTrigConv = ADC_SOFTWARE_START;
	ADC1Handle.Init.DataAlign = ADC_DATAALIGN_RIGHT;
	ADC1Handle.Init.NbrOfConversion = 1;
	ADC1Handle.Init.DMAContinuousRequests = ENABLE;
	ADC1Handle.Init.EOCSelection = ADC_EOC_SINGLE_CONV;
	ADC_Init(&ADC1Handle);

	// 2. Configure for the selected ADC regular channel its corresponding rank in the sequencer and its sample time.
	sConfig.Channel = ADC_CHANNEL_0;
	sConfig.Rank = 1;
	sConfig.SamplingTime = ADC_SAMPLETIME_3CYCLES;
	ADC_ConfigChannel(&ADC1Handle, &sConfig);
}


void DAC1_Init(void)
{
	DAC_ChannelConfTypeDef sConfig = {0};


	DAC1Handle.Instance = DAC;
	DAC_Init(&DAC1Handle);

	sConfig.DAC_Trigger = DAC_TRIGGER_T7_TRGO;
	sConfig.DAC_OutputBuffer = DAC_OUTPUTBUFFER_ENABLE;
	DAC_ConfigChannel(&DAC1Handle, &sConfig, DAC_CHANNEL_1);
}


void TFT1_Init(void)
{
	TFT1Handle.Instance = TFT1;
	TFT1Handle.ScreenMode = 'L';
	TFT1Handle.XcharacterLimit = 40;
	TFT1Handle.YcharacterLimit = 30;
	TFT1Handle.XcharacterLimit_Large = 26;
	TFT1Handle.YcharacterLimit_Large = 30;
	TFT1Handle.nextline_flag = 0;
	TFT1Handle.cursor_flag = 0;
	TFT1Handle.underscore_flag = 0;
	TFT1Handle.outline_flag = 0;
	TFT1Handle.Kfont_type = 'M';

	TFT_Init(&TFT1Handle);
}

/************************************************* Normal Function **************************************************/

void Clear_Graph(TFT_HandleTypeDef *pTFTHandle)
{
	/* Window Re-Setting */

	// 1. x = 50 ~ 300
	TFT_Write(pTFTHandle, 0x02, 50U >> 8);
	TFT_Write(pTFTHandle, 0x03, 50U & 0x00FF);
	TFT_Write(pTFTHandle, 0x04, 300U >> 8);
	TFT_Write(pTFTHandle, 0x05, 300U & 0x00FF);


	// 2. y = 15 ~ 215
	TFT_Write(pTFTHandle, 0x06, 0x0000);
	TFT_Write(pTFTHandle, 0x07, 15U);
	TFT_Write(pTFTHandle, 0x08, 0x0000);
	TFT_Write(pTFTHandle, 0x09, 215U);

	TFT_Command(pTFTHandle, 0x22);



	/* Clear graph */

	// 1. Fill the Window with Black
	for(uint16_t i = 0; i < 251; i++)
	{
		for(uint16_t j = 0; j < 201; j++)
		{
			TFT_Data(pTFTHandle, Black);
		}
	}


	// 2. Draw dotted grid
	if(State == STATE_TIME_DOMAIN)
	{
		for(int i = 100; i <= 300; i = i + 50)
		{
			for(int j = 20; j <= 215; j = j + 5)
			{
				TFT_Pixel(&TFT1Handle, i, j, White);
			}
		}


		for(int j = 23; j <= 183; j = j + 32)
		{
			for(int i = 50; i <= 310; i = i + 5)
			{
				TFT_Pixel(&TFT1Handle, i, j, White);
			}
		}
	}

//	else if( (State == STATE_POSITION) || (State == STATE_POSITION_TRACKING) )
//	{
//		for(int i = 100; i <= 300; i = i + 50)
//		{
//			for(int j = 20; j <= 215; j = j + 5)
//			{
//				TFT_Pixel(pTFTHandle, i, j, White);
//			}
//		}
//
//
//		for(int j = 20; j <= 176; j = j + 39)
//		{
//			for(int i = 50; i <= 310; i = i + 5)
//			{
//				TFT_Pixel(pTFTHandle, i, j, White);
//			}
//		}
//	}



	/* Return the Window setting to its Original state */

	// 1. x = 0 ~ 319
	TFT_Write(pTFTHandle, 0x02, 0x0000);
	TFT_Write(pTFTHandle, 0x03, 0x0000);
	TFT_Write(pTFTHandle, 0x04, 0x0001);
	TFT_Write(pTFTHandle, 0x05, 0x003F);


	// 2. y = 0 ~ 239
	TFT_Write(pTFTHandle, 0x06, 0x0000);
	TFT_Write(pTFTHandle, 0x07, 0x0000);
	TFT_Write(pTFTHandle, 0x08, 0x0000);
	TFT_Write(pTFTHandle, 0x09, 0x00EF);

	TFT_Command(pTFTHandle, 0x22);
}



/************************************************* Callback Function ************************************************/

void TIM_PeriodElapsedCallback(TIM_HandleTypeDef *pTIMHandle)
{
	if(pTIMHandle->Instance == TIM6)
	{
		/* Timer Period is 10us */

		// TFlag is related to Delay functions
		TFlag = FLAG_SET;

		// A/D Conversion is executed every 10us, result of ADC is stored in 'AdcSample' variable
//		ADC_Start_DMA(&ADC1Handle, &AdcSample, 1);
	}
}


void USART_ApplicationEventCallback(UART_HandleTypeDef *pUSARTHandle, uint8_t AppEV)
{
	if(pUSARTHandle->Instance == USART1)
	{
		if(AppEV == USART_EVENT_TX_CMPLT)
		{
			asm("NOP");
		}
	}
}


void ADC_ConvCpltCallback(ADC_HandleTypeDef* pADCHandle)
{

}


void DAC_ConvCpltCallbackCh1(DAC_HandleTypeDef* pDACHandle)
{
	if(pDACHandle->Instance == DAC1)
	{
//		asm("NOP");
	}

}

