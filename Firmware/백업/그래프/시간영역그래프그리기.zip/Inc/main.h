/*
 * main.h
 *
 *  Created on: Mar 7, 2021
 *      Author: Ganghyeok Lim
 */

#ifndef MAIN_H_
#define MAIN_H_

#include "stm32f407xx.h"
#include "common.h"
#include "tft.h"
#include "DSP.h"

#define STATE_INTRO				0
#define STATE_TIME_DOMAIN		1
#define STATE_FREQ_DOMAIN		2

/*================ User configurable parameters =================*/

#define N			256		// Length of Block (must be a power of two)
#define MF			31		// Length of FIR filter
#define L			226		// Length of Input data to be processed at a time => L should be (N-MF+1)

//=================================================================


void LED1_Init(void);

extern uint32_t SystemCoreClock;
extern const uint8_t AHBPrescTable[16];
extern const uint8_t APBPrescTable[8];


extern uint32_t AdcSample;
extern uint32_t DacOutputBuffer[L];

extern uint8_t State;

/* ====================== DSP variables ========================= */
extern uint8_t			InFullFlag;
extern double			InputBuffer[L];
extern double			OutputBuffer[L];
extern uint8_t			OutFullFlag;

//=================================================================





/* ------------------------------- Application Specific ------------------------------- */

/* Application Specific Macro */


/* Application Specific Macro functions */


/* Application Specific C functions */
extern void DMA1_Init(void);
extern void DMA2_Init(void);
extern void LED1_Init(void);
extern void LED2_Init(void);
extern void LED3_Init(void);
extern void LED4_Init(void);
extern void TIM6_Init(void);
extern void TIM7_Init(void);
extern void UART1_Init(void);
extern void ADC1_Init(void);
extern void DAC1_Init(void);
extern void TFT1_Init(void);
extern void MemsetHandleStructure(void);
extern void GATE_DRIVER_Init(void);

extern void State_Intro(void);
extern void State_Time_Domain(void);
extern void State_Freq_Domain(void);

extern void Clear_Graph(TFT_HandleTypeDef *pTFTHandle);

/* Peripheral Handle Definitions */
extern TIM_HandleTypeDef		TIM6Handle;
extern TIM_HandleTypeDef		TIM7Handle;
extern UART_HandleTypeDef		USART1Handle;
extern DMA_HandleTypeDef		DMA2Handle_UART;
extern ADC_HandleTypeDef		ADC1Handle;
extern DMA_HandleTypeDef		DMA2Handle_ADC;
extern DAC_HandleTypeDef		DAC1Handle;
extern DMA_HandleTypeDef		DMA1Handle_DAC;
extern TFT_HandleTypeDef		TFT1Handle;

/* Status Flags */


/* Peripheral Initialization functions */


/* Peripheral Callback functions */






#endif /* MAIN_H_ */
