/*
 * user_func.c
 *
 *  Created on: Mar 7, 2021
 *      Author: Ganghyeok Lim
 */

#include "main.h"


TIM_HandleTypeDef		TIM6Handle;
UART_HandleTypeDef		USART1Handle;
DMA_HandleTypeDef		DMA2Handle;
//ADC_HandleTypeDef		ADC1Handle;


uint32_t SystemCoreClock = 168000000;
const uint8_t AHBPrescTable[16] = {0, 0, 0, 0, 0, 0, 0, 0, 1, 2, 3, 4, 6, 7, 8, 9};
const uint8_t APBPrescTable[8]  = {0, 0, 0, 0, 1, 2, 3, 4};


/********************************************************************************************************************
 * 																											  		*
 *											Application Specific Function											*
 * 																											  		*
 ********************************************************************************************************************/

/********************************************** Initialization Function *********************************************/

void LED1_Init(void)
{
	GPIO_InitTypeDef GPIO_LED;

	memset(&GPIO_LED, 0, sizeof(GPIO_LED));

	GPIO_LED.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_LED.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
	GPIO_LED.Pin = GPIO_PIN_0;

	GPIO_Init(GPIOA, &GPIO_LED);
}

void MemsetHandleStructure(void)
{
	memset(&TIM6Handle, 0, sizeof(TIM6Handle));
	memset(&USART1Handle, 0, sizeof(USART1Handle));
	memset(&DMA2Handle, 0, sizeof(DMA2Handle));
//	memset(&ADC1Handle, 0, sizeof(ADC1Handle));
}

/************************************************* Normal Function *************************************************/








/********************************************************************************************************************
 * 																											  		*
 *											 Peripheral Specific Function											*
 * 																											  		*
 ********************************************************************************************************************/

/********************************************** Initialization Function *********************************************/

void TIM6_Init(void)
{
	// Init TIM6 Base
	TIM6Handle.Instance = TIM6;
	TIM6Handle.Init.CounterMode = TIM_COUNTERMODE_UP;
	TIM6Handle.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
	TIM6Handle.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_ENABLE;
	TIM6Handle.Init.Prescaler = (84-1);	// 84MHz / 84 = 1MHz
	TIM6Handle.Init.Period = (10-1);	// 1MHz / 10 = 100kHz
	TIM_Base_Init(&TIM6Handle);

	// Enable TIM6 interrupt for Update Event
	TIM_ENABLE_IT(&TIM6Handle, TIM_IT_UPDATE);

	// Enable TIM6 Counter
	TIM_ENABLE_COUNTER(&TIM6Handle);
}


void UART1_Init(void)
{
	USART1Handle.Instance = USART1;
	USART1Handle.Init.Mode = UART_MODE_TX;
	USART1Handle.Init.OverSampling = UART_OVERSAMPLING_16;
	USART1Handle.Init.BaudRate = USART_STD_BAUD_115200;
	USART1Handle.Init.Parity = UART_PARITY_NONE;
	USART1Handle.Init.StopBits = UART_STOPBITS_1;
	USART1Handle.Init.HwFlowCtl = UART_HWCONTROL_NONE;
	USART1Handle.Init.WordLength = UART_WORDLENGTH_8B;

	UART_Init(&USART1Handle);
}


void DMA2_Init(void)
{
	// 1. DMA2 Clock Enable
	RCC_DMA2_CLK_ENABLE();

	// 2. Configure NVIC Setting of DMA2_Stream7
	NVIC_IRQConfig(DMA2_Stream7_IRQn, 2, ENABLE);
}




/************************************************* Normal Function **************************************************/





/************************************************* Callback Function ************************************************/

void TIM_PeriodElapsedCallback(TIM_HandleTypeDef *pTIMHandle)
{
	if(pTIMHandle->Instance == TIM6)
	{
		/* TFlag is related to Delay functions */
		TFlag = FLAG_SET;
	}


}


void USART_ApplicationEventCallback(UART_HandleTypeDef *pUSARTHandle, uint8_t AppEV)
{
	if(pUSARTHandle->Instance == USART1)
	{
		if(AppEV == USART_EVENT_TX_CMPLT)
		{
			asm("NOP");
		}
	}
}



