/*
 * it.c
 *
 *  Created on: Mar 7, 2021
 *      Author: Ganghyeok Lim
 */

#include "main.h"


void TIM6_DAC_IRQHandler(void)
{
	TIM_IRQHandling(&TIM6Handle);
}


void USART1_IRQHandler(void)
{
	UART_IRQHandler(&USART1Handle);
}


void ADC_IRQHandler(void)
{
	ADC_IRQHandling(&ADC1Handle);
}


void DMA2_Stream7_IRQHandler(void)
{
	DMA_IRQHandler(&DMA2Handle);
}


void NMI_Handler(void)
{
	while(1);
}


void HardFault_Handler(void)
{
	while(1);
}


void MemManage_Handler(void)
{
	while(1);
}


void BusFault_Handler(void)
{
	while(1);
}


void UsageFault_Handler(void)
{
	while(1);
}
