/*
 * main.h
 *
 *  Created on: Mar 7, 2021
 *      Author: Ganghyeok Lim
 */

#ifndef MAIN_H_
#define MAIN_H_

#include "stm32f407xx.h"
#include "common.h"

void LED1_Init(void);


extern uint32_t SystemCoreClock;
extern const uint8_t AHBPrescTable[16];
extern const uint8_t APBPrescTable[8];


/* ------------------------------- Application Specific ------------------------------- */

/* Application Specific Macro */


/* Application Specific Macro functions */


/* Application Specific C functions */
extern void DMA2_Init(void);
extern void LED1_Init(void);
extern void TIM6_Init(void);
extern void UART1_Init(void);
extern void ADC1_Init(void);
extern void MemsetHandleStructure(void);

/* Peripheral Handle Definitions */
extern TIM_HandleTypeDef		TIM6Handle;
extern UART_HandleTypeDef		USART1Handle;
extern DMA_HandleTypeDef		DMA2Handle_UART;
extern ADC_HandleTypeDef		ADC1Handle;
extern DMA_HandleTypeDef		DMA2Handle_ADC;

/* Status Flags */


/* Peripheral Initialization functions */


/* Peripheral Callback functions */






#endif /* MAIN_H_ */
