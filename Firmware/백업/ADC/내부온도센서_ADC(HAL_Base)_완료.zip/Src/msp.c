/*
 * msp.c
 *
 *  Created on: Mar 7, 2021
 *      Author: Ganghyeok Lim
 */

#include "main.h"


void TIM_Base_MspInit(TIM_HandleTypeDef *pTIMHandle)
{
	if(pTIMHandle->Instance == TIM6)
	{
		// 1. Configure GPIO for TIM
		// TIM6 is used for just time base generation so that GPIO config is not needed

		// 2. Configure CLOCK for TIM
		TIM_PeripheralClockControl(pTIMHandle->Instance, ENABLE);

		// 3. Configure NVIC for TIM
		NVIC_IRQConfig(TIM6_DAC_IRQn, 0, ENABLE);
	}
}


void UART_MspInit(UART_HandleTypeDef *pUSARTHandle)
{
	if(pUSARTHandle->Instance == USART1)
	{
		GPIO_InitTypeDef GPIO_InitStruct = {0};

		/* Peripheral clock enable */
		RCC_USART1_CLK_ENABLE();

	    /**USART1 GPIO Configuration
	    PA9     ------> USART1_TX
	    PA10     ------> USART1_RX
	    */
	   	RCC_GPIOA_CLK_ENABLE();

	    GPIO_InitStruct.Pin = GPIO_PIN_9|GPIO_PIN_10;
	    GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
	    GPIO_InitStruct.Pull = GPIO_NOPULL;
	    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
	    GPIO_InitStruct.Alternate = GPIO_AF7_USART1;
	    GPIO_Init(GPIOA, &GPIO_InitStruct);


	    /* USART1 DMA Init */
	    /* USART1_TX Init */
	    DMA2Handle.Instance = DMA2_Stream7;
	    DMA2Handle.Init.Channel = DMA_CHANNEL_4;
	    DMA2Handle.Init.Direction = DMA_MEMORY_TO_PERIPH;
	    DMA2Handle.Init.PeriphInc = DMA_PINC_DISABLE;
	    DMA2Handle.Init.MemInc = DMA_MINC_ENABLE;
	    DMA2Handle.Init.PeriphDataAlignment = DMA_PDATAALIGN_BYTE;
	    DMA2Handle.Init.MemDataAlignment = DMA_MDATAALIGN_BYTE;
	    DMA2Handle.Init.Mode = DMA_NORMAL;
	    DMA2Handle.Init.Priority = DMA_PRIORITY_LOW;
	    DMA2Handle.Init.FIFOMode = DMA_FIFOMODE_ENABLE;
	    DMA2Handle.Init.FIFOThreshold = DMA_FIFO_THRESHOLD_FULL;
	    DMA2Handle.Init.MemBurst = DMA_MBURST_SINGLE;
	    DMA2Handle.Init.PeriphBurst = DMA_PBURST_SINGLE;
	    DMA_Init(&DMA2Handle);

	    LINKDMA(pUSARTHandle,hdmatx,DMA2Handle);


	    /* USART1 interrupt Init */
	    NVIC_IRQConfig(USART1_IRQn, 1, ENABLE);
	}
}



void ADC_MspInit(ADC_HandleTypeDef* pADCHandle)
{
	GPIO_InitTypeDef GPIO_InitStruct = {0};

	if(pADCHandle->Instance==ADC1)
	{
		// 1. ADC1 Clock Enable
		RCC_ADC1_CLK_ENABLE();

		// 2. GPIO Clock Enable
		RCC_GPIOA_CLK_ENABLE();

		// 3. ADC1 GPIO Configuration (PA0-WKUP -> ADC1_IN0)
	    GPIO_InitStruct.Pin = GPIO_PIN_0;
	    GPIO_InitStruct.Mode = GPIO_MODE_ANALOG;
	    GPIO_InitStruct.Pull = GPIO_NOPULL;
	    GPIO_Init(GPIOA, &GPIO_InitStruct);

	    // 4. ADC NVIC Configuration
	    NVIC_IRQConfig(ADC_IRQn, 4, ENABLE);
	}
}
